<?php 
require_once("./resources/config.php");
include("./resources/cart.php");
?>

<?php include(TEMPLATE_FRONT . DS . "header.php"); ?>

<?php 
    process_transaction();
?>


<div class="container">
	<h1 class="text-center">Thank You</h1>
</div>

<!-- /.container -->

<?php include(TEMPLATE_FRONT . DS . "footer.php"); ?>

<!-- jQuery -->
<script src="js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

</body>

</html>
