
    <div class="container">

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Your Website 2023</p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->